using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using LoansDAL;

public class BalanceDAL
{
	public Connection dbm = new Connection();



}
