﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingDAL
{
   public class CounterTicketEntity
    {
        public string number { get; set; }
        public string first { get; set; }
    }
}
