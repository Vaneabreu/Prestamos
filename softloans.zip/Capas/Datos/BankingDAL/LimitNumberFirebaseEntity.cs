﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingDAL
{
   public class LimitNumberFirebaseEntity
    {
        public string number { get; set; }
        public string limitAmount { get; set; }
        public string lotery { get; set; }
    }
}
