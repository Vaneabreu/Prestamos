﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingDAL
{
   public class VersionEntityFirebase
    {
       public string company { get; set; }
       public string company2 { get; set; }
       public string fontsize { get; set; }
       public string fontsizesubtittle { get; set; }
       public string fontsizetittle { get; set; }
       public string padr { get; set; }
       public string padr2 { get; set; }
       public string urlVersion { get; set; }
       public string versionNumber { get; set; }
       public string fontsizetotal { get; set; }
       public string timecancel { get; set; }
       public string phone { get; set; }
    }
}
