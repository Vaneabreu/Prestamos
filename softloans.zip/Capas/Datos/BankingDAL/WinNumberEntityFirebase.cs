﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingDAL
{
   public class WinNumberEntityFirebase
    {
      public string date { set; get; }
      public string real { set; get; }
      public string ganamas { set; get; }
      public string newyorktarde { set; get; }
      public string loteka { set; get; }
      public string newyorknoche { set; get; }
      public string nacional { set; get; }
      public string leidsa { set; get; }
      public string floridadia { set; get; }
      public string floridanoche { set; get; }
      public string laprimera { set; get; }
      public string lasuerte { set; get; }
    }
}
