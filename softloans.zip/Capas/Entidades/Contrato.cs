﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SoftLoteria.Capas.Entidades
{
    public class Contrato
    {
    }
}