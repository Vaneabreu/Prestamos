﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loans.Entity
{
   public class ReportAmortization
    {

       public string QuotaNumber { get; set; }
       public string PayDate { get; set; }
       public string Quota { get; set; }
       public string Interest { get; set; }
       public string Amortization { get; set; }
       public string Capital { get; set; }

    }
}
